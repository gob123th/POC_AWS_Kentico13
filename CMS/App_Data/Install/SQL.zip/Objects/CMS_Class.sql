SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CMS_Class](
	[ClassID] [int] IDENTITY(1,1) NOT NULL,
	[ClassDisplayName] [nvarchar](100) NOT NULL,
	[ClassName] [nvarchar](100) NOT NULL,
	[ClassUsesVersioning] [bit] NOT NULL,
	[ClassIsDocumentType] [bit] NOT NULL,
	[ClassIsCoupledClass] [bit] NOT NULL,
	[ClassXmlSchema] [nvarchar](max) NOT NULL,
	[ClassFormDefinition] [nvarchar](max) NOT NULL,
	[ClassNodeNameSource] [nvarchar](100) NOT NULL,
	[ClassTableName] [nvarchar](100) NULL,
	[ClassFormLayout] [nvarchar](max) NULL,
	[ClassShowAsSystemTable] [bit] NULL,
	[ClassUsePublishFromTo] [bit] NULL,
	[ClassShowTemplateSelection] [bit] NULL,
	[ClassSKUMappings] [nvarchar](max) NULL,
	[ClassIsMenuItemType] [bit] NULL,
	[ClassNodeAliasSource] [nvarchar](100) NULL,
	[ClassLastModified] [datetime2](7) NOT NULL,
	[ClassGUID] [uniqueidentifier] NOT NULL,
	[ClassCreateSKU] [bit] NULL,
	[ClassIsProduct] [bit] NULL,
	[ClassIsCustomTable] [bit] NOT NULL,
	[ClassShowColumns] [nvarchar](1000) NULL,
	[ClassSearchTitleColumn] [nvarchar](200) NULL,
	[ClassSearchContentColumn] [nvarchar](200) NULL,
	[ClassSearchImageColumn] [nvarchar](200) NULL,
	[ClassSearchCreationDateColumn] [nvarchar](200) NULL,
	[ClassSearchSettings] [nvarchar](max) NULL,
	[ClassInheritsFromClassID] [int] NULL,
	[ClassSearchEnabled] [bit] NULL,
	[ClassSKUDefaultDepartmentName] [nvarchar](200) NULL,
	[ClassSKUDefaultDepartmentID] [int] NULL,
	[ClassContactMapping] [nvarchar](max) NULL,
	[ClassContactOverwriteEnabled] [bit] NULL,
	[ClassSKUDefaultProductType] [nvarchar](50) NULL,
	[ClassConnectionString] [nvarchar](100) NULL,
	[ClassIsProductSection] [bit] NULL,
	[ClassFormLayoutType] [nvarchar](50) NULL,
	[ClassVersionGUID] [nvarchar](50) NULL,
	[ClassDefaultObjectType] [nvarchar](100) NULL,
	[ClassIsForm] [bit] NULL,
	[ClassResourceID] [int] NULL,
	[ClassCustomizedColumns] [nvarchar](400) NULL,
	[ClassCodeGenerationSettings] [nvarchar](max) NULL,
	[ClassIconClass] [nvarchar](200) NULL,
	[ClassURLPattern] [nvarchar](200) NULL,
	[ClassUsesPageBuilder] [bit] NOT NULL,
	[ClassIsNavigationItem] [bit] NOT NULL,
	[ClassHasURL] [bit] NOT NULL,
	[ClassHasMetadata] [bit] NOT NULL,
	[ClassSearchIndexDataSource] [int] NULL,
 CONSTRAINT [PK_CMS_Class] PRIMARY KEY NONCLUSTERED 
(
	[ClassID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO
SET ANSI_PADDING ON
GO
CREATE CLUSTERED INDEX [IX_CMS_Class_ClassID_ClassName_ClassDisplayName] ON [dbo].[CMS_Class]
(
	[ClassID] ASC,
	[ClassName] ASC,
	[ClassDisplayName] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
SET ANSI_PADDING ON
GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_CMS_Class_ClassName] ON [dbo].[CMS_Class]
(
	[ClassName] ASC
)
INCLUDE([ClassXmlSchema],[ClassTableName]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
SET ANSI_PADDING ON
GO
CREATE NONCLUSTERED INDEX [IX_CMS_Class_ClassName_ClassGUID] ON [dbo].[CMS_Class]
(
	[ClassName] ASC,
	[ClassGUID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
CREATE NONCLUSTERED INDEX [IX_CMS_Class_ClassResourceID] ON [dbo].[CMS_Class]
(
	[ClassResourceID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
CREATE NONCLUSTERED INDEX [IX_CMS_Class_ClassShowAsSystemTable_ClassIsCustomTable_ClassIsCoupledClass_ClassIsDocumentType] ON [dbo].[CMS_Class]
(
	[ClassShowAsSystemTable] ASC,
	[ClassIsCustomTable] ASC,
	[ClassIsCoupledClass] ASC,
	[ClassIsDocumentType] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
ALTER TABLE [dbo].[CMS_Class] ADD  CONSTRAINT [DEFAULT_CMS_Class_ClassUsesVersioning]  DEFAULT ((0)) FOR [ClassUsesVersioning]
GO
ALTER TABLE [dbo].[CMS_Class] ADD  CONSTRAINT [DEFAULT_CMS_Class_ClassIsDocumentType]  DEFAULT ((0)) FOR [ClassIsDocumentType]
GO
ALTER TABLE [dbo].[CMS_Class] ADD  CONSTRAINT [DEFAULT_CMS_Class_ClassIsCoupledClass]  DEFAULT ((0)) FOR [ClassIsCoupledClass]
GO
ALTER TABLE [dbo].[CMS_Class] ADD  CONSTRAINT [DEFAULT_CMS_Class_ClassIsCustomTable]  DEFAULT ((0)) FOR [ClassIsCustomTable]
GO
ALTER TABLE [dbo].[CMS_Class] ADD  CONSTRAINT [DEFAULT_CMS_Class_ClassUsesPageBuilder]  DEFAULT ((0)) FOR [ClassUsesPageBuilder]
GO
ALTER TABLE [dbo].[CMS_Class] ADD  CONSTRAINT [DEFAULT_CMS_Class_ClassIsNavigationItem]  DEFAULT ((0)) FOR [ClassIsNavigationItem]
GO
ALTER TABLE [dbo].[CMS_Class] ADD  CONSTRAINT [DEFAULT_CMS_Class_ClassHasURL]  DEFAULT ((0)) FOR [ClassHasURL]
GO
ALTER TABLE [dbo].[CMS_Class] ADD  CONSTRAINT [DEFAULT_CMS_Class_ClassHasMetadata]  DEFAULT ((0)) FOR [ClassHasMetadata]
GO
ALTER TABLE [dbo].[CMS_Class]  WITH CHECK ADD  CONSTRAINT [FK_CMS_Class_ClassResourceID_CMS_Resource] FOREIGN KEY([ClassResourceID])
REFERENCES [dbo].[CMS_Resource] ([ResourceID])
GO
ALTER TABLE [dbo].[CMS_Class] CHECK CONSTRAINT [FK_CMS_Class_ClassResourceID_CMS_Resource]
GO
