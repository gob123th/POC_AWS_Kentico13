SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Analytics_ExitPages](
	[ExitPageLastModified] [datetime2](7) NOT NULL,
	[ExitPageSiteID] [int] NOT NULL,
	[ExitPageCulture] [nvarchar](50) NULL,
	[ExitPageId] [int] IDENTITY(1,1) NOT NULL,
	[ExitPageUrl] [nvarchar](1000) NOT NULL,
	[ExitPageSessionIdentifier] [uniqueidentifier] NOT NULL,
 CONSTRAINT [PK_Analytics_ExitPages] PRIMARY KEY CLUSTERED 
(
	[ExitPageId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_Analytics_ExitPages_ExitPageLastModified] ON [dbo].[Analytics_ExitPages]
(
	[ExitPageLastModified] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
CREATE UNIQUE NONCLUSTERED INDEX [UQ_Analytics_ExitPages_ExitPageSessionIdentifier] ON [dbo].[Analytics_ExitPages]
(
	[ExitPageSessionIdentifier] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
ALTER TABLE [dbo].[Analytics_ExitPages] ADD  CONSTRAINT [DEFAULT_Analytics_ExitPages_ExitPageUrl]  DEFAULT (N'') FOR [ExitPageUrl]
GO
ALTER TABLE [dbo].[Analytics_ExitPages] ADD  CONSTRAINT [DEFAULT_Analytics_ExitPages_ExitPageSessionIdentifier]  DEFAULT ('00000000-0000-0000-0000-000000000000') FOR [ExitPageSessionIdentifier]
GO
ALTER TABLE [dbo].[Analytics_ExitPages]  WITH CHECK ADD  CONSTRAINT [FK_Analytics_ExitPages_ExitPageSiteID_CMS_Site] FOREIGN KEY([ExitPageSiteID])
REFERENCES [dbo].[CMS_Site] ([SiteID])
GO
ALTER TABLE [dbo].[Analytics_ExitPages] CHECK CONSTRAINT [FK_Analytics_ExitPages_ExitPageSiteID_CMS_Site]
GO
