SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CMS_SiteDomainAlias](
	[SiteDomainAliasID] [int] IDENTITY(1,1) NOT NULL,
	[SiteDomainAliasName] [nvarchar](400) NULL,
	[SiteID] [int] NOT NULL,
	[SiteDefaultVisitorCulture] [nvarchar](50) NULL,
	[SiteDomainGUID] [uniqueidentifier] NULL,
	[SiteDomainLastModified] [datetime2](7) NOT NULL,
	[SiteDomainPresentationUrl] [nvarchar](400) NULL,
	[SiteDomainAliasType] [int] NOT NULL,
 CONSTRAINT [PK_CMS_SiteDomainAlias] PRIMARY KEY CLUSTERED 
(
	[SiteDomainAliasID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO
SET ANSI_PADDING ON
GO
CREATE NONCLUSTERED INDEX [IX_CMS_SiteDomainAlias_SiteDomainAliasName] ON [dbo].[CMS_SiteDomainAlias]
(
	[SiteDomainAliasName] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
CREATE NONCLUSTERED INDEX [IX_CMS_SiteDomainAlias_SiteID] ON [dbo].[CMS_SiteDomainAlias]
(
	[SiteID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
ALTER TABLE [dbo].[CMS_SiteDomainAlias] ADD  CONSTRAINT [DEFAULT_CMS_SiteDomainAlias_SiteDomainAliasType]  DEFAULT ((0)) FOR [SiteDomainAliasType]
GO
ALTER TABLE [dbo].[CMS_SiteDomainAlias]  WITH CHECK ADD  CONSTRAINT [FK_CMS_SiteDomainAlias_SiteID_CMS_Site] FOREIGN KEY([SiteID])
REFERENCES [dbo].[CMS_Site] ([SiteID])
GO
ALTER TABLE [dbo].[CMS_SiteDomainAlias] CHECK CONSTRAINT [FK_CMS_SiteDomainAlias_SiteID_CMS_Site]
GO
