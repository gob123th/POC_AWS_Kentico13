SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CMS_WebFarmServer](
	[ServerID] [int] IDENTITY(1,1) NOT NULL,
	[ServerDisplayName] [nvarchar](300) NOT NULL,
	[ServerName] [nvarchar](300) NOT NULL,
	[ServerGUID] [uniqueidentifier] NULL,
	[ServerLastModified] [datetime2](7) NOT NULL,
	[ServerEnabled] [bit] NOT NULL,
	[IsExternalWebAppServer] [bit] NOT NULL,
 CONSTRAINT [PK_CMS_WebFarmServer] PRIMARY KEY NONCLUSTERED 
(
	[ServerID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO
SET ANSI_PADDING ON
GO
CREATE CLUSTERED INDEX [IX_CMS_WebFarmServer_ServerDisplayName] ON [dbo].[CMS_WebFarmServer]
(
	[ServerDisplayName] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
SET ANSI_PADDING ON
GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_CMS_WebFarmServer_ServerName] ON [dbo].[CMS_WebFarmServer]
(
	[ServerName] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
ALTER TABLE [dbo].[CMS_WebFarmServer] ADD  CONSTRAINT [DEFAULT_CMS_WebFarmServer_ServerDisplayName]  DEFAULT (N'') FOR [ServerDisplayName]
GO
ALTER TABLE [dbo].[CMS_WebFarmServer] ADD  CONSTRAINT [DEFAULT_CMS_WebFarmServer_ServerName]  DEFAULT (N'') FOR [ServerName]
GO
ALTER TABLE [dbo].[CMS_WebFarmServer] ADD  CONSTRAINT [DEFAULT_CMS_WebFarmServer_ServerLastModified]  DEFAULT ('9/17/2013 12:18:06 PM') FOR [ServerLastModified]
GO
ALTER TABLE [dbo].[CMS_WebFarmServer] ADD  CONSTRAINT [DEFAULT_CMS_WebFarmServer_ServerEnabled]  DEFAULT ((0)) FOR [ServerEnabled]
GO
ALTER TABLE [dbo].[CMS_WebFarmServer] ADD  CONSTRAINT [DEFAULT_CMS_WebFarmServer_IsExternalWebAppServer]  DEFAULT ((0)) FOR [IsExternalWebAppServer]
GO
