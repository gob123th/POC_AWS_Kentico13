SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CMS_PageTemplateCategory](
	[CategoryID] [int] IDENTITY(1,1) NOT NULL,
	[CategoryDisplayName] [nvarchar](200) NOT NULL,
	[CategoryParentID] [int] NULL,
	[CategoryName] [nvarchar](200) NULL,
	[CategoryGUID] [uniqueidentifier] NOT NULL,
	[CategoryLastModified] [datetime2](7) NOT NULL,
	[CategoryImagePath] [nvarchar](450) NULL,
	[CategoryChildCount] [int] NULL,
	[CategoryTemplateChildCount] [int] NULL,
	[CategoryPath] [nvarchar](450) NULL,
	[CategoryLevel] [int] NULL,
 CONSTRAINT [PK_CMS_PageTemplateCategory] PRIMARY KEY NONCLUSTERED 
(
	[CategoryID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO
SET ANSI_PADDING ON
GO
CREATE UNIQUE CLUSTERED INDEX [IX_CMS_PageTemplateCategory_CategoryPath] ON [dbo].[CMS_PageTemplateCategory]
(
	[CategoryPath] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
CREATE NONCLUSTERED INDEX [IX_CMS_PageTemplateCategory_CategoryLevel] ON [dbo].[CMS_PageTemplateCategory]
(
	[CategoryLevel] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
CREATE NONCLUSTERED INDEX [IX_CMS_PageTemplateCategory_CategoryParentID] ON [dbo].[CMS_PageTemplateCategory]
(
	[CategoryParentID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
ALTER TABLE [dbo].[CMS_PageTemplateCategory] ADD  CONSTRAINT [DEFAULT_CMS_PageTemplateCategory_CategoryDisplayName]  DEFAULT ('') FOR [CategoryDisplayName]
GO
ALTER TABLE [dbo].[CMS_PageTemplateCategory] ADD  CONSTRAINT [DEFAULT_CMS_PageTemplateCategory_CategoryChildCount]  DEFAULT ((0)) FOR [CategoryChildCount]
GO
ALTER TABLE [dbo].[CMS_PageTemplateCategory] ADD  CONSTRAINT [DEFAULT_CMS_PageTemplateCategory_CategoryTemplateChildCount]  DEFAULT ((0)) FOR [CategoryTemplateChildCount]
GO
ALTER TABLE [dbo].[CMS_PageTemplateCategory]  WITH CHECK ADD  CONSTRAINT [FK_CMS_PageTemplateCategory_CategoryParentID_CMS_PageTemplateCategory] FOREIGN KEY([CategoryParentID])
REFERENCES [dbo].[CMS_PageTemplateCategory] ([CategoryID])
GO
ALTER TABLE [dbo].[CMS_PageTemplateCategory] CHECK CONSTRAINT [FK_CMS_PageTemplateCategory_CategoryParentID_CMS_PageTemplateCategory]
GO
ALTER TABLE [dbo].[CMS_PageTemplateCategory]  WITH CHECK ADD  CONSTRAINT [CK_CMS_PageTemplateCategory_CategoryLevel] CHECK  (([CategoryLevel]>=(0)))
GO
ALTER TABLE [dbo].[CMS_PageTemplateCategory] CHECK CONSTRAINT [CK_CMS_PageTemplateCategory_CategoryLevel]
GO
