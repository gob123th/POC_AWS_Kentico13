SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[COM_OrderAddress](
	[AddressID] [int] IDENTITY(1,1) NOT NULL,
	[AddressLine1] [nvarchar](100) NOT NULL,
	[AddressLine2] [nvarchar](100) NULL,
	[AddressCity] [nvarchar](100) NOT NULL,
	[AddressZip] [nvarchar](20) NOT NULL,
	[AddressPhone] [nvarchar](26) NULL,
	[AddressCountryID] [int] NOT NULL,
	[AddressStateID] [int] NULL,
	[AddressPersonalName] [nvarchar](200) NOT NULL,
	[AddressGUID] [uniqueidentifier] NULL,
	[AddressLastModified] [datetime2](7) NOT NULL,
	[AddressOrderID] [int] NOT NULL,
	[AddressType] [int] NOT NULL,
 CONSTRAINT [PK_COM_OrderAddress] PRIMARY KEY CLUSTERED 
(
	[AddressID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_COM_OrderAddress_AddressCountryID] ON [dbo].[COM_OrderAddress]
(
	[AddressCountryID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_COM_OrderAddress_AddressOrderID_AddressType] ON [dbo].[COM_OrderAddress]
(
	[AddressOrderID] ASC,
	[AddressType] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, FILLFACTOR = 90)
GO
CREATE NONCLUSTERED INDEX [IX_COM_OrderAddress_AddressStateID] ON [dbo].[COM_OrderAddress]
(
	[AddressStateID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
ALTER TABLE [dbo].[COM_OrderAddress] ADD  CONSTRAINT [DEFAULT_COM_OrderAddress_AddressOrderID]  DEFAULT ((0)) FOR [AddressOrderID]
GO
ALTER TABLE [dbo].[COM_OrderAddress] ADD  CONSTRAINT [DEFAULT_COM_OrderAddress_AddressType]  DEFAULT ((0)) FOR [AddressType]
GO
ALTER TABLE [dbo].[COM_OrderAddress]  WITH CHECK ADD  CONSTRAINT [FK_COM_OrderAddress_AddressCountryID_CMS_Country] FOREIGN KEY([AddressCountryID])
REFERENCES [dbo].[CMS_Country] ([CountryID])
GO
ALTER TABLE [dbo].[COM_OrderAddress] CHECK CONSTRAINT [FK_COM_OrderAddress_AddressCountryID_CMS_Country]
GO
ALTER TABLE [dbo].[COM_OrderAddress]  WITH CHECK ADD  CONSTRAINT [FK_COM_OrderAddress_AddressOrderID_COM_Order] FOREIGN KEY([AddressOrderID])
REFERENCES [dbo].[COM_Order] ([OrderID])
GO
ALTER TABLE [dbo].[COM_OrderAddress] CHECK CONSTRAINT [FK_COM_OrderAddress_AddressOrderID_COM_Order]
GO
ALTER TABLE [dbo].[COM_OrderAddress]  WITH CHECK ADD  CONSTRAINT [FK_COM_OrderAddress_AddressStateID_CMS_State] FOREIGN KEY([AddressStateID])
REFERENCES [dbo].[CMS_State] ([StateID])
GO
ALTER TABLE [dbo].[COM_OrderAddress] CHECK CONSTRAINT [FK_COM_OrderAddress_AddressStateID_CMS_State]
GO
