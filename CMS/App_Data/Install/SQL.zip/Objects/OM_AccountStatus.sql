SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[OM_AccountStatus](
	[AccountStatusID] [int] IDENTITY(1,1) NOT NULL,
	[AccountStatusName] [nvarchar](200) NOT NULL,
	[AccountStatusDisplayName] [nvarchar](200) NOT NULL,
	[AccountStatusDescription] [nvarchar](max) NULL,
 CONSTRAINT [PK_OM_AccountStatus] PRIMARY KEY CLUSTERED 
(
	[AccountStatusID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO
