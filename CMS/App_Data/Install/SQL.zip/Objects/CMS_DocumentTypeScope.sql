SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CMS_DocumentTypeScope](
	[ScopeID] [int] IDENTITY(1,1) NOT NULL,
	[ScopePath] [nvarchar](450) NOT NULL,
	[ScopeSiteID] [int] NULL,
	[ScopeLastModified] [datetime2](7) NOT NULL,
	[ScopeGUID] [uniqueidentifier] NULL,
	[ScopeIncludeChildren] [bit] NULL,
	[ScopeAllowAllTypes] [bit] NULL,
	[ScopeAllowLinks] [bit] NULL,
	[ScopeMacroCondition] [nvarchar](max) NULL,
 CONSTRAINT [PK_CMS_DocumentTypeScope] PRIMARY KEY NONCLUSTERED 
(
	[ScopeID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO
SET ANSI_PADDING ON
GO
CREATE CLUSTERED INDEX [IX_CMS_DocumentTypeScope_ScopePath] ON [dbo].[CMS_DocumentTypeScope]
(
	[ScopePath] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
CREATE NONCLUSTERED INDEX [IX_CMS_DocumentTypeScope_ScopeSiteID] ON [dbo].[CMS_DocumentTypeScope]
(
	[ScopeSiteID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
ALTER TABLE [dbo].[CMS_DocumentTypeScope] ADD  CONSTRAINT [DEFAULT_CMS_DocumentTypeScope_ScopePath]  DEFAULT ('') FOR [ScopePath]
GO
ALTER TABLE [dbo].[CMS_DocumentTypeScope] ADD  CONSTRAINT [DEFAULT_CMS_DocumentTypeScope_ScopeLastModified]  DEFAULT ('4/30/2013 2:47:21 PM') FOR [ScopeLastModified]
GO
ALTER TABLE [dbo].[CMS_DocumentTypeScope] ADD  CONSTRAINT [DEFAULT_CMS_DocumentTypeScope_ScopeAllowAllTypes]  DEFAULT ((0)) FOR [ScopeAllowAllTypes]
GO
ALTER TABLE [dbo].[CMS_DocumentTypeScope] ADD  CONSTRAINT [DEFAULT_CMS_DocumentTypeScope_ScopeAllowLinks]  DEFAULT ((0)) FOR [ScopeAllowLinks]
GO
ALTER TABLE [dbo].[CMS_DocumentTypeScope]  WITH CHECK ADD  CONSTRAINT [FK_CMS_DocumentTypeScope_ScopeSiteID_CMS_Site] FOREIGN KEY([ScopeSiteID])
REFERENCES [dbo].[CMS_Site] ([SiteID])
GO
ALTER TABLE [dbo].[CMS_DocumentTypeScope] CHECK CONSTRAINT [FK_CMS_DocumentTypeScope_ScopeSiteID_CMS_Site]
GO
