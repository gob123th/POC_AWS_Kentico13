SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CMS_Avatar](
	[AvatarID] [int] IDENTITY(1,1) NOT NULL,
	[AvatarName] [nvarchar](200) NULL,
	[AvatarFileName] [nvarchar](200) NOT NULL,
	[AvatarFileExtension] [nvarchar](10) NOT NULL,
	[AvatarBinary] [varbinary](max) NULL,
	[AvatarGUID] [uniqueidentifier] NOT NULL,
	[AvatarLastModified] [datetime2](7) NOT NULL,
	[AvatarMimeType] [nvarchar](100) NOT NULL,
	[AvatarFileSize] [int] NOT NULL,
	[AvatarImageHeight] [int] NULL,
	[AvatarImageWidth] [int] NULL,
 CONSTRAINT [PK_CMS_Avatar] PRIMARY KEY NONCLUSTERED 
(
	[AvatarID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO
SET ANSI_PADDING ON
GO
CREATE CLUSTERED INDEX [IX_CMS_Avatar_AvatarName] ON [dbo].[CMS_Avatar]
(
	[AvatarName] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
CREATE NONCLUSTERED INDEX [IX_CMS_Avatar_AvatarGUID] ON [dbo].[CMS_Avatar]
(
	[AvatarGUID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
