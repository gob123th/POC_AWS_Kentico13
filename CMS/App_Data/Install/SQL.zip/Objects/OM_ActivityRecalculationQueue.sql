SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[OM_ActivityRecalculationQueue](
	[ActivityRecalculationQueueID] [int] IDENTITY(1,1) NOT NULL,
	[ActivityRecalculationQueueActivityID] [int] NOT NULL,
 CONSTRAINT [PK_OM_ActivityRecalculationQueue] PRIMARY KEY CLUSTERED 
(
	[ActivityRecalculationQueueID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO
ALTER TABLE [dbo].[OM_ActivityRecalculationQueue] ADD  CONSTRAINT [DEFAULT_OM_ActivityRecalculationQueue_ActivityRecalculationQueueActivityID]  DEFAULT ((0)) FOR [ActivityRecalculationQueueActivityID]
GO
