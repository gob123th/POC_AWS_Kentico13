SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[Proc_OM_ContactChangeRecalculationQueue_FetchContactChanges]
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DELETE TOP (10000) FROM [OM_ContactChangeRecalculationQueue] OUTPUT deleted.*
END
GO
