SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CMS_Document](
	[DocumentID] [int] IDENTITY(1,1) NOT NULL,
	[DocumentName] [nvarchar](100) NOT NULL,
	[DocumentModifiedWhen] [datetime2](7) NULL,
	[DocumentModifiedByUserID] [int] NULL,
	[DocumentForeignKeyValue] [int] NULL,
	[DocumentCreatedByUserID] [int] NULL,
	[DocumentCreatedWhen] [datetime2](7) NULL,
	[DocumentCheckedOutByUserID] [int] NULL,
	[DocumentCheckedOutWhen] [datetime2](7) NULL,
	[DocumentCheckedOutVersionHistoryID] [int] NULL,
	[DocumentPublishedVersionHistoryID] [int] NULL,
	[DocumentWorkflowStepID] [int] NULL,
	[DocumentPublishFrom] [datetime2](7) NULL,
	[DocumentPublishTo] [datetime2](7) NULL,
	[DocumentCulture] [nvarchar](50) NOT NULL,
	[DocumentNodeID] [int] NOT NULL,
	[DocumentPageTitle] [nvarchar](max) NULL,
	[DocumentPageKeyWords] [nvarchar](max) NULL,
	[DocumentPageDescription] [nvarchar](max) NULL,
	[DocumentContent] [nvarchar](max) NULL,
	[DocumentCustomData] [nvarchar](max) NULL,
	[DocumentTags] [nvarchar](max) NULL,
	[DocumentTagGroupID] [int] NULL,
	[DocumentLastPublished] [datetime2](7) NULL,
	[DocumentSearchExcluded] [bit] NULL,
	[DocumentLastVersionNumber] [nvarchar](50) NULL,
	[DocumentIsArchived] [bit] NULL,
	[DocumentGUID] [uniqueidentifier] NULL,
	[DocumentWorkflowCycleGUID] [uniqueidentifier] NULL,
	[DocumentIsWaitingForTranslation] [bit] NULL,
	[DocumentSKUName] [nvarchar](440) NULL,
	[DocumentSKUDescription] [nvarchar](max) NULL,
	[DocumentSKUShortDescription] [nvarchar](max) NULL,
	[DocumentWorkflowActionStatus] [nvarchar](450) NULL,
	[DocumentCanBePublished] [bit] NOT NULL,
	[DocumentPageBuilderWidgets] [nvarchar](max) NULL,
	[DocumentPageTemplateConfiguration] [nvarchar](max) NULL,
	[DocumentABTestConfiguration] [nvarchar](max) NULL,
	[DocumentShowInMenu] [bit] NOT NULL,
	[DocumentUnpublishedRedirectUrl] [nvarchar](450) NULL,
 CONSTRAINT [PK_CMS_Document] PRIMARY KEY CLUSTERED 
(
	[DocumentID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_CMS_Document_DocumentCheckedOutByUserID] ON [dbo].[CMS_Document]
(
	[DocumentCheckedOutByUserID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
CREATE NONCLUSTERED INDEX [IX_CMS_Document_DocumentCheckedOutVersionHistoryID] ON [dbo].[CMS_Document]
(
	[DocumentCheckedOutVersionHistoryID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
CREATE NONCLUSTERED INDEX [IX_CMS_Document_DocumentCreatedByUserID] ON [dbo].[CMS_Document]
(
	[DocumentCreatedByUserID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
SET ANSI_PADDING ON
GO
CREATE NONCLUSTERED INDEX [IX_CMS_Document_DocumentCulture] ON [dbo].[CMS_Document]
(
	[DocumentCulture] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
CREATE NONCLUSTERED INDEX [IX_CMS_Document_DocumentForeignKeyValue_DocumentID_DocumentNodeID] ON [dbo].[CMS_Document]
(
	[DocumentForeignKeyValue] ASC,
	[DocumentID] ASC,
	[DocumentNodeID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
CREATE NONCLUSTERED INDEX [IX_CMS_Document_DocumentModifiedByUserID] ON [dbo].[CMS_Document]
(
	[DocumentModifiedByUserID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
SET ANSI_PADDING ON
GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_CMS_Document_DocumentNodeID_DocumentID_DocumentCulture] ON [dbo].[CMS_Document]
(
	[DocumentNodeID] ASC,
	[DocumentID] ASC,
	[DocumentCulture] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
CREATE NONCLUSTERED INDEX [IX_CMS_Document_DocumentPublishedVersionHistoryID] ON [dbo].[CMS_Document]
(
	[DocumentPublishedVersionHistoryID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
CREATE NONCLUSTERED INDEX [IX_CMS_Document_DocumentTagGroupID] ON [dbo].[CMS_Document]
(
	[DocumentTagGroupID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
CREATE NONCLUSTERED INDEX [IX_CMS_Document_DocumentWorkflowStepID] ON [dbo].[CMS_Document]
(
	[DocumentWorkflowStepID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
ALTER TABLE [dbo].[CMS_Document] ADD  CONSTRAINT [DEFAULT_CMS_Document_DocumentCulture]  DEFAULT (N'') FOR [DocumentCulture]
GO
ALTER TABLE [dbo].[CMS_Document] ADD  CONSTRAINT [DEFAULT_CMS_Document_DocumentCanBePublished]  DEFAULT ((1)) FOR [DocumentCanBePublished]
GO
ALTER TABLE [dbo].[CMS_Document] ADD  CONSTRAINT [DEFAULT_CMS_Document_DocumentShowInMenu]  DEFAULT ((0)) FOR [DocumentShowInMenu]
GO
ALTER TABLE [dbo].[CMS_Document]  WITH CHECK ADD  CONSTRAINT [FK_CMS_Document_DocumentCheckedOutByUserID_CMS_User] FOREIGN KEY([DocumentCheckedOutByUserID])
REFERENCES [dbo].[CMS_User] ([UserID])
GO
ALTER TABLE [dbo].[CMS_Document] CHECK CONSTRAINT [FK_CMS_Document_DocumentCheckedOutByUserID_CMS_User]
GO
ALTER TABLE [dbo].[CMS_Document]  WITH CHECK ADD  CONSTRAINT [FK_CMS_Document_DocumentCheckedOutVersionHistoryID_CMS_VersionHistory] FOREIGN KEY([DocumentCheckedOutVersionHistoryID])
REFERENCES [dbo].[CMS_VersionHistory] ([VersionHistoryID])
GO
ALTER TABLE [dbo].[CMS_Document] CHECK CONSTRAINT [FK_CMS_Document_DocumentCheckedOutVersionHistoryID_CMS_VersionHistory]
GO
ALTER TABLE [dbo].[CMS_Document]  WITH CHECK ADD  CONSTRAINT [FK_CMS_Document_DocumentCreatedByUserID_CMS_User] FOREIGN KEY([DocumentCreatedByUserID])
REFERENCES [dbo].[CMS_User] ([UserID])
GO
ALTER TABLE [dbo].[CMS_Document] CHECK CONSTRAINT [FK_CMS_Document_DocumentCreatedByUserID_CMS_User]
GO
ALTER TABLE [dbo].[CMS_Document]  WITH CHECK ADD  CONSTRAINT [FK_CMS_Document_DocumentModifiedByUserID_CMS_User] FOREIGN KEY([DocumentModifiedByUserID])
REFERENCES [dbo].[CMS_User] ([UserID])
GO
ALTER TABLE [dbo].[CMS_Document] CHECK CONSTRAINT [FK_CMS_Document_DocumentModifiedByUserID_CMS_User]
GO
ALTER TABLE [dbo].[CMS_Document]  WITH CHECK ADD  CONSTRAINT [FK_CMS_Document_DocumentNodeID_CMS_Tree] FOREIGN KEY([DocumentNodeID])
REFERENCES [dbo].[CMS_Tree] ([NodeID])
GO
ALTER TABLE [dbo].[CMS_Document] CHECK CONSTRAINT [FK_CMS_Document_DocumentNodeID_CMS_Tree]
GO
ALTER TABLE [dbo].[CMS_Document]  WITH CHECK ADD  CONSTRAINT [FK_CMS_Document_DocumentPublishedVersionHistoryID_CMS_VersionHistory] FOREIGN KEY([DocumentPublishedVersionHistoryID])
REFERENCES [dbo].[CMS_VersionHistory] ([VersionHistoryID])
GO
ALTER TABLE [dbo].[CMS_Document] CHECK CONSTRAINT [FK_CMS_Document_DocumentPublishedVersionHistoryID_CMS_VersionHistory]
GO
ALTER TABLE [dbo].[CMS_Document]  WITH CHECK ADD  CONSTRAINT [FK_CMS_Document_DocumentTagGroupID_CMS_TagGroup] FOREIGN KEY([DocumentTagGroupID])
REFERENCES [dbo].[CMS_TagGroup] ([TagGroupID])
GO
ALTER TABLE [dbo].[CMS_Document] CHECK CONSTRAINT [FK_CMS_Document_DocumentTagGroupID_CMS_TagGroup]
GO
ALTER TABLE [dbo].[CMS_Document]  WITH CHECK ADD  CONSTRAINT [FK_CMS_Document_DocumentWorkflowStepID_CMS_WorkflowStep] FOREIGN KEY([DocumentWorkflowStepID])
REFERENCES [dbo].[CMS_WorkflowStep] ([StepID])
GO
ALTER TABLE [dbo].[CMS_Document] CHECK CONSTRAINT [FK_CMS_Document_DocumentWorkflowStepID_CMS_WorkflowStep]
GO
