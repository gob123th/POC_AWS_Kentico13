SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CMS_MacroIdentity](
	[MacroIdentityID] [int] IDENTITY(1,1) NOT NULL,
	[MacroIdentityGuid] [uniqueidentifier] NOT NULL,
	[MacroIdentityLastModified] [datetime2](7) NOT NULL,
	[MacroIdentityName] [nvarchar](200) NOT NULL,
	[MacroIdentityEffectiveUserID] [int] NULL,
 CONSTRAINT [PK_CMS_MacroIdentity] PRIMARY KEY CLUSTERED 
(
	[MacroIdentityID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_CMS_MacroIdentity_MacroIdentityEffectiveUserID] ON [dbo].[CMS_MacroIdentity]
(
	[MacroIdentityEffectiveUserID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
ALTER TABLE [dbo].[CMS_MacroIdentity] ADD  CONSTRAINT [DEFAULT_CMS_MacroIdentity_MacroIdentityGuid]  DEFAULT ('00000000-0000-0000-0000-000000000000') FOR [MacroIdentityGuid]
GO
ALTER TABLE [dbo].[CMS_MacroIdentity] ADD  CONSTRAINT [DEFAULT_CMS_MacroIdentity_MacroIdentityLastModified]  DEFAULT ('1/1/0001 12:00:00 AM') FOR [MacroIdentityLastModified]
GO
ALTER TABLE [dbo].[CMS_MacroIdentity] ADD  CONSTRAINT [DEFAULT_CMS_MacroIdentity_MacroIdentityName]  DEFAULT (N'') FOR [MacroIdentityName]
GO
ALTER TABLE [dbo].[CMS_MacroIdentity]  WITH CHECK ADD  CONSTRAINT [FK_CMS_MacroIdentity_MacroIdentityEffectiveUserID_CMS_User] FOREIGN KEY([MacroIdentityEffectiveUserID])
REFERENCES [dbo].[CMS_User] ([UserID])
GO
ALTER TABLE [dbo].[CMS_MacroIdentity] CHECK CONSTRAINT [FK_CMS_MacroIdentity_MacroIdentityEffectiveUserID_CMS_User]
GO
